function validar() {
			var email = login.email.value;
			var senha = login.senha.value
			var regex = /^(?=(?:.*?[A-Z]){1})(?=(?:.*?[0-9]){1})(?=(?:.*?[!@#$%*()_+^&}{:;?.]){1})(?!.*\s)[0-9a-zA-Z!@#$%;*(){}_+^&]*$/;

			if (email == "") {
				alert('Login não preenchido!');
				login.email.focus();
				return false;
								}
			if (senha == "") {
				alert('Senha não preenchida!');
				login.senha.focus();
				return false;
								}
			if (senha.length < 5) {
				alert('Sua senha deve conter mais de 5 digitos!')
				login.senha.focus();
				return false;
			}
			if (senha.length > 10) {
				alert('Sua senha não deve conter mais de 10 digitos!')
				login.senha.focus();
				return false;
			}
			if (senha.length > 10) {
				alert('Sua senha não deve conter mais de 10 digitos!')
			}
			else if(!regex.exec(senha))
{
    alert("Sua senha deve conter letras, números e caracter especial!");
    document.login.senha.focus();
    return false;
}
		}